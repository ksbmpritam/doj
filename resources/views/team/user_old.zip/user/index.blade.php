@extends('team.layouts.app')

@section('content')
<div class="page-wrapper">
    <form action="{{ url ('team/update/'. $team->id)}}" method="Post" enctype="multipart/form-data">
        @csrf
        <div class="row page-titles">
            <div class="col-md-5 align-self-center">
                <h3 class="text-themecolor">Details</h3>
            </div>

            <div class="col-md-7 align-self-center">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{url('team/dashboard')}}">{{trans('lang.dashboard')}}</a></li>
                    </li>
                </ol>
            </div>
        </div>

        <div class="container-fluid">
            <div class="cat-edite-page max-width-box">
                <div class="card  pb-4">

                    <!--<div class="card-header">-->
                    <!--    <ul class="nav nav-tabs align-items-end card-header-tabs w-100  justify-content-center">-->
                    <!--        <li class="nav-item" style="border: 1px solid #ff683a;border-radius:2px">-->
                    <!--            <a class="nav-link " href="{!! route('team.dashboard') !!}"><i class="fa fa-list mr-2"></i>Dashboard</a>-->
                    <!--        </li>-->
                    <!--        <li class="nav-item" style="border: 1px solid #ff683a;border-radius:2px">-->
                    <!--            <a class="nav-link active" href="{!! url()->current() !!}"><i class="fa fa-plu mr-2"></i>User Detail</a>-->
                    <!--        </li>-->
                    <!--    </ul>-->
                    <!--</div>-->

                    <div class="card-body">

                        <div id="data-table_processing" class="dataTables_processing panel panel-default" style="display: none;">
                            {{trans('lang.processing')}}
                        </div>
                        <div class="error_top" style="display:none"></div>
                        <div class="row restaurant_payout_create" role="tabpanel">

                            <div class="restaurant_payout_create-inner tab-content">
                                <div role="tabpanel" class="tab-pane active" id="category_information">
                                    <fieldset>
                                        <legend>Details</legend>
                                        <div class="form-group row width-50">
                                            <label class="col-3 control-label">Name</label>
                                            <div class="col-7">
                                                <input type="text" class="form-control" name="name" value="{{ $team->name }}" readonly>
                                                <div class="form-text text-muted">
                                                    @error('name')
                                                    <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row width-50">
                                            <label class="col-3 control-label">Mobile No.</label>
                                            <div class="col-7">
                                                <input type="text" class="form-control" id="mobile_no" onkeypress="return numeralsOnly(event)" maxlength="10" name="mobile_no" value="{{ $team->mobile_no }}" readonly>
                                                <div class="form-text text-muted">
                                                    @error('mobile_no')
                                                    <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row width-50">
                                            <label class="col-3 control-label">Email</label>
                                            <div class="col-7">
                                                <input type="email" class="form-control" name="email" value="{{ $team->email }}" readonly>
                                                <div class="form-text text-muted">
                                                    @error('email')
                                                    <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row width-50">
                                            <label class="col-3 control-label">Password</label>
                                            <div class="col-7">
                                                <input type="text" class="form-control" name="password" value="{{ $team->pwd }}" readonly>

                                                <div class="form-text text-muted">
                                                    @error('password')
                                                    <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row width-50">
                                            <label class="col-3 control-label">Profile Image</label>
                                            <div class="col-7">
                                              <!--<input type="file" class="form-control" id="profile" name="images" readonly>-->
                                               <div id="uploding_image">
                                                    @if($team->image)
                                                        <img src="{{ asset('images/team/profile/' . $team->image) }}" width="100" height="100" alt="Photo">
                                                    @else
                                                        profile image not found
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row width-100">
                                            <label class="col-3 control-label">Permanent Address</label>
                                            <div class="col-7">
                                                <input type="text" class="form-control" id="permanent_address" name="permanent_address" value="{{ $team->permanent_address }}" readonly>
                                                <div class="form-text text-muted">
                                                    @error('permanent_address')
                                                    <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-check row width-100">
                                            <input  type="checkbox" class="item_publish" name="address_same" id="address_same" value="1"
                                                @if($team->address_same == 1) checked @endif >
                                            <label class="col-3 control-label" for="address_same">Communication Address Same as Permanent Address</label>
                                            @error('address_same')
                                            <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>

                                        <div class="form-group row width-100">
                                            <label class="col-3 control-label"> Communication Address</label>
                                            <div class="col-7">
                                                <input type="text" class="form-control" id="communication_address" name="communication_address" @if($team->communication_address == 1) readonly @endif value="{{ $team->communication_address }}" readonly>
                                                <div class="form-text text-muted">
                                                    @error('communication_address')
                                                    <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row width-50">
                                            <label class="col-3 control-label"> PAN No.</label>
                                            <div class="col-7">
                                                <input type="text" class="form-control" id="pan_card_no" name="pan_card_no" value="{{ $team->pan_card_no }}" readonly>
                                                <div class="form-text text-muted">
                                                    @error('pan_card_no')
                                                    <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row width-50">
                                            <label class="col-3 control-label"> Aadhar No.</label>
                                            <div class="col-7">
                                                <input type="text" class="form-control" id="aadhar_no" maxlength="12" onkeypress="return numerOnly(event)" name="aadhar_no" value="{{ $team->aadhar_no }}" readonly>
                                                <div class="form-text text-muted">
                                                    @error('aadhar_no')
                                                    <span class="text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-check row width-100">
                                            <input type="checkbox" class="item_publish" name="status" id="status" value="1" @if($team->status == 1) checked @endif readonly> 
                                            <label class="col-3 control-label" for="status">{{ trans('lang.item_publish') }}</label>
                                            @error('status')
                                            <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </fieldset>

                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-group col-12 text-center btm-btn">
                        <a href="{!! route('team.dashboard') !!}" class="btn btn-default"><i class="fa fa-undo"></i>{{trans('lang.cancel')}}</a>
                    </div>

                </div>
            </div>
        </div>
    </form>
</div>
</div>

@endsection
<script>
    document.addEventListener("DOMContentLoaded", function () {
        var checkbox = document.getElementById("address_same");
        checkbox.addEventListener("click", function () {
            this.checked = true; // Always keep the checkbox checked
        });
    });
</script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        var checkbox = document.getElementById("status");
        checkbox.addEventListener("click", function () {
            this.checked = true; // Always keep the checkbox checked
        });
    });
</script>

